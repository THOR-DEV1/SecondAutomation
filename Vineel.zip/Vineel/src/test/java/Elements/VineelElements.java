package Elements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import BrowserSetup.BrowserDriver;

public class VineelElements {
	WebDriver driver=BrowserDriver.getCurrentDriver();
	@FindBy(xpath="//*[@id=\"InvestingPlanning\"]/div[3]/ul/li/div[3]/span[1]/span") WebElement btnyes;
	@FindBy(xpath="//*[@id=\"wzrk_wrapper\"]/div[2]") WebElement Alert;
	@FindBy(xpath="//*[@id=\"wzrk-cancel\"]") WebElement Cancel;
	@FindBy(xpath="//*[@id=\"salary\"]") WebElement Amount;
	@FindBy(xpath="//*[@id=\"year\"]") WebElement year;
	@FindBy(xpath="//*[@id=\"graduity_calc_btn\"]") WebElement Submitbtn;
	@FindBy(xpath="//*[@id=\"graduity_amt\"]") WebElement CalAmount;
	public VineelElements ClickOnYes() {
		btnyes.click();
		return this;
		
	}
	public VineelElements Alerts() {
		boolean s=Alert.isDisplayed();
		if(s==true) {
			Cancel.click();
		}else {
			System.out.println("no popup");
		}
		return this;
		
	}
	public VineelElements Amountenter() {
		Amount.sendKeys("20000");
		return this;
		
	}
	public VineelElements Yearsenter() {
		year.sendKeys("12");
		return this;
		
	}
	public VineelElements Subbtn() {
		Submitbtn.click();
		return this;
		
	}
	public VineelElements validate() {
		String s1=CalAmount.getText();
		float i=Float.parseFloat(s1.replace(",", ""));
		float Execpted=Math.round(i);
		float d= (float) ((0.5769230769230769)*20000*12);
		float Actual= Math.round(d);
		if(Execpted==Actual) {
			System.out.println("Actual Amount==Execpted Amount");
		}else {
			System.out.println("Actual!=Execpted");
		}
		return this;
		
	}
	public VineelElements Close() {
		driver.close();
		return this;
	}
	
}
